const yaml = require("js-yaml");
const fs = require("fs");
const color = require("ansi-colors");
let OpenAI;

try {
    OpenAI = require("openai");
} catch (error) {
    console.error(color.red('Error: "openai" package is not installed.'));
    console.error(color.red('Please install it by running: npm install openai'));
    process.exit(1);
}

const config = yaml.load(fs.readFileSync("./addons/ChatGPT/config.yml", "utf8"));

module.exports.register = ({ on, client }) => {
    const systemMessage = fs.readFileSync("./addons/ChatGPT/system.txt", "utf-8");

    const openai = new OpenAI({
        apiKey: config.ChatGPTSettings.APIKey,
    });

    const messageStore = {};

    on("messageCreate", async (message) => {
        if (message.channel.id !== config.ChatGPTSettings.ChannelID) return;
        if (!message.guild) return;
        if (message.author.bot || message.author.id === message.client.user.id) return;

        const content = message.content;
        const userID = message.author.id;

        if (!messageStore[userID]) messageStore[userID] = [];

        const messageData = [
            { role: "system", content: systemMessage },
            { role: "user", content: content },
        ];

        // Add the new message data to the user's message history
        messageStore[userID].push(...messageData);

        // Limit message history to the last 30 entries
        if (messageStore[userID].length > 30) messageStore[userID].shift();

        try {
            await message.channel.sendTyping();

            const modelRequest = {
                model: config.ChatGPTSettings.Model,
                messages: messageStore[userID],
                temperature: 0,
                max_tokens: 1024,
            };

            const response = await openai.chat.completions.create(modelRequest);

            if (response.choices && response.choices.length > 0) {
                const generatedReply = response.choices[0].message.content;
                await message.reply(generatedReply);
            } else {
                console.log("The generated reply is empty or the response format is not as expected.");
                message.reply("❌ The generated reply is empty or the response format is not as expected.");
            }
        } catch (error) {
            console.error("Error while generating reply:", error);
            message.reply("❌ An error occurred while trying to generate a reply, please try again.");
        }
    });
};
